# Gamify
My team's submission for HSHacks IV #Team2k

## What is Gamify?
Gamify is a scalable interface for using games to study. Using the dashboard, the user can create study sets, and launch them into games that will quiz the user on the study sets.

## How do I use Gamify?

Setup:
1. Download the latest stable release [here]()
2. Extract the contents into a folder you would like to store it in.
3. Ensure you have [jre](https://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html) or [jdk](https://www.oracle.com/technetwork/java/javase/downloads/index.html) installed.
4. Run Dashboard.jar either by double-clicking it or through the terminal with "java -jar Dashboard.jar"
5. Enjoy and have fun

Creating Data Sets:

Creating Your Own Game:


## Contributors
- [Me](https://github.com/digitaldisarray/): Dashboard
- [Eylam](https://github.com/EylamTagor/): Match
- [Brian](https://github.com/brianla0616): Tetris
- [Ayush](https://github.com/ayushsat): Snake
